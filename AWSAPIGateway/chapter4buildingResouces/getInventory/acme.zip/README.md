

$> npm install faker  

